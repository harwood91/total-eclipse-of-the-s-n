=== Facebook Widget ===
Contributors: Milap
Tags: facebook, facebook like box, facebook simple like, facebook fan pages, facebook like button, facebook button share, facebook social bookmarking, facebook feeds, facebook feed widget, social share, wordpress social share, socialmedia, social media widget, social media sharing, social media icon 
Donate link: https://www.paypal.com/cgi-bin/webscr?business=cemilap.88@gmail.com&cmd=_xclick¤cy_code=USD&amount=5&item_name=Offer%20me%20coffee
Requires at least: 3.0.1
Tested up to: 4.6
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This widget adds a Simple Facebook page Like Widget into your WordPress website Sidebar or Footer area. Also enabled short code for POST and PAGE.

== Description ==

One of the most popular plugin for facebook page feeds widget with over 3,40,000 downloads and 80,000+ active installs.

An inside look:

http://www.youtube.com/watch?v=H1xjvIw9aZk

This widget will provide you the most simple and attractive way to display Facebook page likes into your wordpress sidebar. It is very easy to configure with Admin area. You just need to activate plugin and drag this widget like other widgets. Just add application id from your created facebook application, add it into widget and also URL of your Facebook page. You also have other options like show faces , show Data Stream and Header.

In latest version, support to short code is added to display Facebook like plugin into your post and pages.
Open your Post or Page, Add [fb_widget] into Post or Page, Save it. You are done.

If you have any question regarding plugin, mail me on cemilap.88@gmail.com or add me on [Facebook](http://www.facebook.com/milap112). or you can contact me on my [Blog](http://patelmilap.wordpress.com/contact-me/).I will try to reply you as soon as possible.

If my Plugin worked for you, please leave your review [Here](https://wordpress.org/support/view/plugin-reviews/facebook-pagelike-widget?filter=5) , so people can use it with confidence. God bless you..!!


== Installation ==

Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.

For more details,

http://codex.wordpress.org/Managing_Plugins

== Frequently Asked Questions ==


= How to use shortcode ? =
* You can use below shortcode in Post or Page.
`[fb_widget fb_url="http://www.facebook.com/Instagram"]`
You can use more parameters like below.
`[fb_widget fb_url="http://www.facebook.com/Instagram" width="500" height="450" data_small_header="false" select_lng="ru_RU" data_adapt_container_width="false" data_hide_cover="false" data_show_facepile="false" data_show_posts="true"]`

= Widget doesn't working in Mozilla Firefox  = 
* If widget works great in all browsers except Mozilla Firefox, You must press the settings off "Use protection against tracking in private window", its security settings for Mozilla, nothing to do with my plugin.

= How do I sign up for a Facebook application ID for my website = 
* You may create a new Facebook application or edit your existing Facebook application through the [Facebook Developers application interface](https://developers.facebook.com/apps/). You need to signup for a Facebook Developer account first.

= I am not sure how to get Facebook application ID ? =
* If you are not able to create Facebook application or you do not know how to do that, do not worry, you can use my default application id `1590918427791514` . I have created it for plugin users and it should work like a charm for you.

== Screenshots ==

1. See screenshot-1.png - Shows how your plugin will display in frontend.
2. screenshot-2.png - Explains how you can configure plugin in admin widget area.

== Other Notes ==

I have tested my widget with following themes. Please let me know your theme name, if my widget also works with it.

* Twenty Fifteen (https://wordpress.org/themes/twentyfifteen/)
* Twenty Fourteen (http://wordpress.org/themes/twentyfourteen)
* Twenty Thirteen (http://wordpress.org/themes/twentythirteen)
* Twenty Twelve (http://wordpress.org/themes/twentytwelve)
* Twenty Eleven (http://wordpress.org/themes/twentyeleven)
* Avada (http://themeforest.net/item/avada-responsive-multipurpose-theme/2833226)
* Photography (http://themeforest.net/item/photography-responsive-photography-theme/13304399)
* Simply Read (https://wordpress.org/themes/simply-read/)
* Evolve (https://wordpress.org/themes/evolve/)
* Eco Nature - Environment & Ecology (http://themeforest.net/item/eco-nature-environment-ecology-wordpress-theme/8497776/)
* Mantra (https://wordpress.org/themes/mantra/)
* Weaver-ii (https://wordpress.org/themes/weaver-ii/)
* Bazar (http://preview.yithemes.com/bazar/)
* News Pro (http://my.studiopress.com/themes/news/)

== Changelog ==

= Version 4.1 =
* Now you can add individual widget into Page or Post using shortcode.

= Version 4.0 =
* Changes in code to make plugin compitable for Translation.

= Version 3.1 =
* Removed offset warning for language dropdown.

= Version 3.0 =
* Plugin updated to Facebook Graph API v2.3.
* Removed old options like show/hide border, color scheme.
* Removed notices and warnings.
* Added unclosed div.

= Version 2.3 =
* Added options like Border, Language and custom css to shortcode function.

= Version 2.2 =

* Added support for localization (Multilanguage support)(Added .pot file)
* Added option to add custom css for widget
* Added option to select language to show your Facebook widget in any language you want.

= Version 2.1 =

* Added option to show or hide border from widget
* Added default values to all needed fields while you setup widget, it will help you.

== Upgrade Notice ==

* With the release of Graph API v2.3, the Like Box plugin is deprecated. Please use the updated Plugin instead. The Page Plugin allows you to embed a simple feed of content from a Page into your websites.
* If you do not manually upgrade to the Page Plugin, your Like Box plugin implementation will automatically fall back to the Page Plugin by June 23rd 2015.
